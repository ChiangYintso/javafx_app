package main.java.pers.jiangyinzuo.rollcall.service;

public interface TeacherService {

}
