package main.java.pers.jiangyinzuo.rollcall.ui;

public interface AbstractMenu {
	static final String EXIT = "exit";
	
	String getMenuClassName();
}
