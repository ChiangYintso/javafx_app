package main.java.pers.jiangyinzuo.rollcall.service.Impl;

import main.java.pers.jiangyinzuo.rollcall.entity.Teacher;
import main.java.pers.jiangyinzuo.rollcall.service.TeacherService;
import main.java.pers.jiangyinzuo.rollcall.service.validator.Validator;

public class TeacherServiceImpl implements TeacherService {
	
}

