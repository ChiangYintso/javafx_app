package test.java.pers.jiangyinzuo.rollcall.daoTest;

import main.java.pers.jiangyinzuo.rollcall.dao.fileImpl.ScheduleDaoFileImpl;
import main.java.pers.jiangyinzuo.rollcall.dao.ScheduleDao;

public class ScheduleDaoFileImplTest {
	public static void main(String[] args) {
		ScheduleDao dao = new ScheduleDaoFileImpl();

	}
}
